Completed checks for Financial Pessimism and the Timing of Saving
15 October 2026

Decision: enough for a modest descriptive research note, with uncertain publication
prospects. The historical timing reversal is robust; the original causal doom-
spending, agency and recent-generational claims are unsupported.

Contents
- report/: final assessment PDF, with literature access limits and source links.
- analysis/prepare_pilot.py: builds the narrow augmented baseline extract.
- analysis/checks/: household-resource, weighting, attrition, transition and
  verification code; results/ contains aggregate estimates and metadata only.
- manifest.json: SHA-256 hashes for packaged files.

No person-level records, pickle caches, downloaded papers or full questionnaires
are included. Source data and the original project were read, not modified.

Reproduction on the user's machine
Requires Python with pandas, numpy; reportlab, pypdf, pypdfium2 and Pillow are
needed only for the PDF and its layout verification. No scipy/statsmodels needed.
This package uses the existing cohort extract AND the original tab files:
  C:/Hansak/Data/UKHLS_derived/bhps_ukhls_cohort_long_raw.csv
  C:/Hansak/Data/UKDA-6614-tab/tab/bhps and /ukhls
  C:/Hansak/Data/UKDA-6614-tab/mrdoc/ukda_data_dictionaries.zip
The input locations are constants in prepare_pilot.py and prepare_checks.py.
The cohort extract was created in the earlier project; this package does not
reconstruct that original extract from scratch. It verifies unique person/source/
wave keys and supplements its variables from the raw release.

From the extracted package root, execute in order:
  python analysis/prepare_pilot.py
  python analysis/checks/prepare_checks.py
  python analysis/checks/complete_equivalence.py
  python analysis/checks/run_remaining.py
  python analysis/checks/attrition_checks.py
  python analysis/checks/history_checks.py
  python analysis/checks/transition_checks.py
  python analysis/checks/verify_results.py
  python analysis/checks/build_assessment.py
  python analysis/checks/render_assessment.py
The build script writes the PDF to outputs/ relative to the extracted root.
The authoring marker in the Codex PDF skill is an app workflow requirement, not
a dependency for independently running this Python analysis.

Estimation and timing
Outlook categories: 1 better, 2 worse, 3 unchanged. Pessimism and optimism are
separate indicators; unchanged is the reference. Young means ages 18-34; older
means 35-59, measured at the forecast. The outcome is putting aside any personal
income beyond regular bills, not a net-saving flow or a consumption measure.

Primary pairs link exact adjacent survey waves within source and require 6-18
months between actual interview months. BHPS saving is available annually;
UKHLS saving is asked in Waves 2,4,6,8,10,13, so its forecast waves are
1,3,5,7,9,12. Strict timing and transitions require a saving observation strictly
before the forecast and another after it, each 6-18 months from the forecast.
UKHLS Wave-12's earlier saving report is generally too old for that strict timing
sample; rare pairs remain eligible if their actual interview gaps satisfy it.
Interview dates can overlap across survey waves. Such overlaps are excluded
from strict timing/transition models; non-prior reports are also excluded from
the saving-history predictors in the attrition model.

Resources
Household gross income uses fihhmngrs_dv. BHPS net uses weekly hhneti converted
to monthly; UKHLS net uses fihhmnnet1_dv before council tax. These are not fully
identical concepts. Use within-source-wave ranks and separate-source results.
BHPS equivalence factors are computed from indall household rosters (ages under
14 versus 14+). Of 109,688 comparable households, 165 native factors differ from
the roster factor by more than 1e-6, with maximum absolute difference 0.2. Both
gross and net models consistently use the roster factor. This
avoids dropping gross-income households merely because the net-income subset's
equivalence factor is missing. UKHLS uses ieqmoecd_dv. Household composition,
employment, tenure and valid marital categories are retained. No claim is made
that debt service or annual liquid wealth has been fully measured.

Weights and inference
Endpoint interview longitudinal weights must have a base no later than the
earliest required observation. Published LW exclude some intermittent respondents.
Positive weights are normalized within forecast wave before pooling; resulting
coefficients are descriptive projections, not population saving-rate estimates.
The PSU/strata identifiers come from the harmonized xwavedat file. Inference uses
stratified PSU score covariance, an absorbed-parameter degrees-of-freedom
adjustment and centered singleton-stratum treatment. Unweighted estimates use
the same design variance. Estimator/covariance code is validated against a full-
dummy synthetic regression; this is not an independent Stata/R replication.

Tailored response weights start from positive baseline cross-sectional weights
and adjust by weighted logit follow-up probability, fitted separately by source
and forecast wave. Predictors are baseline-only, including saving history when
actually observed before or at the baseline. Death/out-of-scope/institutional
individual dispositions 99/54/55 are excluded. Probability clipping [.05,.995]
and a within-wave 99th-percentile weight-cap sensitivity are documented. IPW
standard errors condition on estimated response weights; no first-step bootstrap
has been used. The published-weight estimates provide the main inference.

MNAR sensitivity entries are completed-data point projections, not valid CIs.
Only missing pessimists' saving probabilities are shifted relative to baseline
model predictions; other missing outcomes retain their predictions. Nonparametric
worst-case bounds instead allow all missing binary outcomes to range freely.
Those bounds describe unadjusted weighted group means in the baseline risk set,
not the fixed-effect coefficient. Neither check identifies a causal mechanism.

Tables
resource_weight_estimates.csv: resource, source, published-weight and history
  comparisons; effects/SE/CI in probability units (multiply by 100 for pp).
attrition_weight_estimates.csv: baseline-XW and tailored-IPW comparisons.
weighted_transition_estimates.csv: next saving conditional on strictly earlier
  saving status. For prior savers, negate effect/CI to describe exit.
history_estimates.csv: balanced-window and change-without-person-FE checks.
MNAR_point_sensitivity.csv: assumption-dependent completed-data point contrasts.
attrition_worst_case_bounds.csv: unadjusted group bounds, not FE bounds.
response_by_outlook.csv, response_propensity_audit.csv, tailored_weight_audit.csv,
  attrition_risk_set.csv: risk set, calibration, overlap and weight diagnostics.
analysis_coverage.csv, resource_coverage.csv, equivalence_audit.csv,
  published_weight_coverage.csv: variable/sample coverage and equivalence audit.
variable_definitions.csv, control_sets.json: source metadata and model controls.
identity_checks.csv, verification.json: executed internal checks.
literature_access_record.json: sources and what was actually accessible.

Limits
These analyses were developed after exploring earlier project results. Treat
age interactions and specification searches as exploratory, not preregistered.
The outcome is reported saving participation. Time-varying shocks, expectations
feedback, measurement error, missing resources and unobserved response selection
remain. No inference of luxury spending, loss of agency or a recent youth-specific
behavioural change is justified. The full final Brown-Taylor 2006 journal paper
was not accessible; its author draft and published abstract were compared and
clearly distinguished. A submission still needs that final priority check.
