from pathlib import Path
import json
import pandas as pd
from run_remaining import collect

HERE=Path(__file__).resolve().parent
q=pd.read_pickle(HERE/'analysis_panel_LOCAL.pkl')
terms=json.loads((HERE/'results'/'control_sets.json').read_text())['gross']
q=q[(q.response==1)&q.previous_gap.between(6,18)&q.previous_save.notna()].copy()
rows=[]
for src in ['BHPS','UKHLS']:
    for s in [0,1]:
        g=q[(q.source==src)&(q.previous_save==s)].copy()
        # Negating next-saving coefficient for prior savers yields exit contrast.
        rows+=collect(src+('_prior_savers' if s else '_prior_nonsavers'),g,['next_save'],terms,'next_published_trip_weight')
        pd.DataFrame(rows).to_csv(HERE/'results'/'weighted_transition_estimates.csv',index=False)
