from pathlib import Path
import json
import numpy as np
import pandas as pd
from check_stats import synthetic_check

HERE=Path(__file__).resolve().parent
R=HERE/'results'
synthetic_check()
checks=[]
files=['resource_weight_estimates.csv','attrition_weight_estimates.csv','history_estimates.csv','weighted_transition_estimates.csv']
expected_models=[19,7,2,4]
for file,expected in zip(files,expected_models):
    d=pd.read_csv(R/file)
    assert d.model.nunique()==expected,(file,'Incomplete model collection')
    assert not d.duplicated(['model','outcome','contrast']).any()
    assert np.isfinite(d[['effect','se','lo95','hi95']].to_numpy()).all()
    assert (d.lo95<=d.effect).all() and (d.hi95>=d.effect).all()
    assert (d.effective_N<=d.N+1e-6).all()
    for (model,ct),g in d.groupby(['model','contrast']):
        gg=g.set_index('outcome')
        for change,prior in [('next_minus_current','save'),('next_minus_previous','previous_save')]:
            if not {change,prior,'next_save'}.issubset(gg.index):continue
            assert gg.N.nunique()==1 and gg.persons.nunique()==1
            err=abs(gg.loc[change,'effect']-(gg.loc['next_save','effect']-gg.loc[prior,'effect']))
            assert err<1e-10
            checks.append(dict(file=file,model=model,contrast=ct,identity_max_error=err))
    # Young effect minus older effect must equal interaction.
    for (model,y),g in d.groupby(['model','outcome']):
        gg=g.set_index('contrast')
        assert abs(gg.loc['ages18_34','effect']-gg.loc['ages35_59','effect']-gg.loc['young_minus_older','effect'])<1e-10
q=pd.read_pickle(HERE/'analysis_panel_LOCAL.pkl')
assert q.loc[q.equiv_gross.notna()|q.equiv_net.notna(),'eq_check'].gt(0).all()
assert not q.duplicated(['pidp','source','wave']).any()
assert q.loc[q.response==1,'gap'].between(6,18).all()
used=q[(q.response==1)&q.previous_save.notna()&q.previous_gap.between(6,18)]
assert (used.previous_date_month<used.date_month).all()
assert q.loc[q.known_exit,'response'].sum()==0
assert set(q.loc[q.source=='UKHLS','wave'].unique())=={1,3,5,7,9,12}
pa=pd.read_csv(R/'response_propensity_audit.csv')
assert len(pa)==23
assert (pa.p_min>0).all() and (pa.p_max<1).all()
assert pa.max_score.max()<1e-5
assert abs(pa.response_weighted-pa.predicted_response_weighted).max()<1e-5
ms=pd.read_csv(R/'MNAR_point_sensitivity.csv')
assert len(ms)==21 and not ms.duplicated(['source','delta_pessimistic_missing','outcome']).any()
audit={
 'status':'PASS',
 'estimator_check':'Weighted alternating fixed effects and stratified PSU score covariance agree with explicit full-dummy regression on unbalanced synthetic data.',
 'logit_check':'Constant-probability likelihood solution and all fitted response scores verified.',
 'timing_identities_checked':len(checks),
 'max_timing_identity_error':max(c['identity_max_error'] for c in checks),
 'unique_person_source_wave':True,
 'all_followup_gaps_6_to_18_months':True,
 'positive_equivalence_factors_for_all_used_income_values':True,
 'all_prior_saving_gaps_used_in_timing_transitions_strictly_positive':True,
 'raw_previous_saving_reports_with_nonpositive_gap_excluded_from_history':int((q.previous_save.notna()&(q.previous_gap<=0)).sum()),
 'known_exits_with_observed_followup':0,
 'max_propensity_score_error':float(pa.max_score.max()),
 'max_response_calibration_error':float(abs(pa.response_weighted-pa.predicted_response_weighted).max()),
 'low_probability_clipped':int(pa.clipped_low.sum()),
 'high_probability_clipped':int(pa.clipped_high.sum()),
 'scope':'Internal numerical and pairing verification; not independent causal validation or a second statistical-package replication.'
}
(R/'verification.json').write_text(json.dumps(audit,indent=2))
pd.DataFrame(checks).to_csv(R/'identity_checks.csv',index=False)
print(json.dumps(audit,indent=2))
