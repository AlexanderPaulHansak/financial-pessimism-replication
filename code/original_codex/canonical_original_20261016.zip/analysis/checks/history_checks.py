from pathlib import Path
import json
import pandas as pd
from run_remaining import collect

HERE=Path(__file__).resolve().parent
q=pd.read_pickle(HERE/'analysis_panel_LOCAL.pkl')
terms=json.loads((HERE/'results'/'control_sets.json').read_text())['gross']
b=q[(q.source=='BHPS')&(q.response==1)].dropna(subset=terms+['psu','strata','save','next_save']).copy()
rows=[]
# Identical respondents observed at every annual forecast wave 4--14.
g=b[b.wave.between(4,14)].copy()
g=g[g.groupby('pidp').wave.transform('nunique')==11].copy()
rows+=collect('BHPS_balanced_waves4_14',g,['save','next_save','next_minus_current'],terms)
# Change-in-saving projection without absorbing person intercepts a second time.
# Differencing already removes an additive, time-invariant saving propensity.
rows+=collect('BHPS_change_without_person_FE',b,['next_minus_current'],terms,fe=False)
pd.DataFrame(rows).to_csv(HERE/'results'/'history_estimates.csv',index=False)
