"""Remaining household-resource, weighting and attrition checks.

No respondent records are exported. All estimates are descriptive projections.
"""
from pathlib import Path
import json
import numpy as np
import pandas as pd
from check_stats import fit,contrast,synthetic_check,logit_irls

HERE=Path(__file__).resolve().parent
OUT=HERE/'results';OUT.mkdir(exist_ok=True)

def make_panel():
    d=pd.read_pickle(HERE/'household_augmented_LOCAL.pkl')
    assert not d.duplicated(['pidp','source','wave']).any()
    d['published_pair_weight']=np.nan;d['published_trip_weight']=np.nan
    d['published_weight_name']='';d['published_trip_weight_name']=''
    for (src,wv),g in d.groupby(['source','wave']):
        wv=int(wv)
        if src=='BHPS':
            pair='indin91_lw' if wv<=9 else ('indin99_lw' if wv<=11 else 'indin01_lw')
            trip='indin91_lw' if wv<=10 else ('indin99_lw' if wv<=12 else 'indin01_lw')
        else:
            pair='indinus_lw' if wv<=2 else ('indinub_lw' if wv<=6 else 'indinui_lw')
            trip=pair
        for name,col,lab in [(pair,'published_pair_weight','published_weight_name'),(trip,'published_trip_weight','published_trip_weight_name')]:
            if name in d and g[name].notna().any():
                d.loc[g.index,col]=g[name];d.loc[g.index,lab]=name
    endpoints=['save','date_month','finnow','equiv_gross','equiv_net','hh_size','tenure','hh_employed','published_pair_weight','published_trip_weight','published_weight_name','published_trip_weight_name','indin91_lw']
    nxt=d[['pidp','source','wave']+endpoints].copy();nxt['wave']-=1
    nxt=nxt.rename(columns={c:'next_'+c for c in endpoints})
    q=d.merge(nxt,on=['pidp','source','wave'],how='left',validate='one_to_one')
    savewaves={'BHPS':list(range(1,19)),'UKHLS':[2,4,6,8,10,13]}
    prev=[]
    for src,ws in savewaves.items():
        for end in ws:
            before=[w for w in ws if w<end-1]
            if not before:continue
            pw=max(before)
            a=d[(d.source==src)&(d.wave==pw)][['pidp','save','date_month','equiv_gross','equiv_net']].copy()
            a['source']=src;a['wave']=end-1
            a=a.rename(columns={c:'previous_'+c for c in ['save','date_month','equiv_gross','equiv_net']})
            prev.append(a)
    q=q.merge(pd.concat(prev),on=['pidp','source','wave'],how='left',validate='one_to_one')
    q['gap']=q.next_date_month-q.date_month;q['previous_gap']=q.date_month-q.previous_date_month
    q['young']=(q.age<35).astype(float);q['pess']=(q.fin_future_code==2).astype(float);q['optim']=(q.fin_future_code==1).astype(float)
    q['pess_young']=q.pess*q.young;q['optim_young']=q.optim*q.young
    q['age2']=((q.age-40)/10)**2
    q['timecell']=q.source+'_'+q.wave.astype(str)+'_'+q.interview_year.fillna(-1).astype(int).astype(str)
    q['next_minus_current']=q.next_save-q.save;q['next_minus_previous']=q.next_save-q.previous_save
    q=q.copy()
    short=['pess','optim','pess_young','optim_young','young','age2']
    individual=[]
    for col,values,valid in [('finnow',range(2,6),q.finnow.between(1,5)),('employment_complete',list(range(2,16))+[97],q.employment_complete.notna())]:
        for v in values:
            name=f'{col}_{v}';q[name]=(q[col]==v).astype(float).where(valid);individual.append(name)
    ranks=[]
    for col,label in [('gross_income','personal'),('equiv_gross','hhgross'),('equiv_net','hhnet')]:
        rank=q.groupby(['source','wave'])[col].rank(pct=True)
        for v in range(2,6):
            name=label+'_q'+str(v);q[name]=(np.ceil(rank*5).clip(1,5)==v).astype(float).where(rank.notna());ranks.append((label,name))
    iterms=short+individual+[n for l,n in ranks if l=='personal']
    composition=[]
    for col,values,ref,cap in [('hh_size',[1,2,3,4,5],1,5),('hh_kids',[0,1,2,3],0,3),('hh_employed',[0,1,2,3],1,3)]:
        clean=q[col].clip(upper=cap)
        for v in values:
            if v==ref:continue
            name=f'{col}_{v}';q[name]=(clean==v).astype(float).where(q[col].notna());composition.append(name)
    for col,vals,ref in [('marital_validated',list(range(1,11)),1),('tenure',list(range(1,9)),2)]:
        for v in vals:
            if v==ref:continue
            name=f'{col}_{v}';q[name]=(q[col]==v).astype(float).where(q[col].isin(vals));composition.append(name)
    gross=iterms+composition+[n for l,n in ranks if l=='hhgross']
    net=iterms+composition+[n for l,n in ranks if l=='hhnet']
    scheduled=np.zeros(len(q),bool)
    for src,ws in savewaves.items():scheduled|=(q.source==src)&q.wave.isin([w-1 for w in ws])
    q=q[scheduled&q.age.between(18,59)&q.fin_future_code.isin([1,2,3])].copy()
    q['known_exit']=q.next_disposition.isin([99,54,55])
    q['response']=(q.next_save.notna()&q.gap.between(6,18)).astype(float)
    q['baseline_weight']=q.weight_xw
    # Cross-sectional base weights are used only as the base of a tailored
    # response adjustment, never mislabeled as longitudinal weights.
    for c in ['baseline_weight','next_published_pair_weight','next_published_trip_weight','next_indin91_lw']:
        q[c]=q[c].where(q[c]>0)
        q[c]=q[c]/q.groupby(['source','wave'])[c].transform('mean')
    return q,short,iterms,gross,net

contrasts=[('ages18_34',{'pess':1,'pess_young':1}),('ages35_59',{'pess':1}),('young_minus_older',{'pess_young':1})]
def collect(name,frame,ys,terms,weight=None,fe=True,minT=2):
    r=fit(frame,ys,terms,weight=weight,fe=fe,design=True,minT=minT)
    rows=[]
    for y in ys:
        for label,ct in contrasts:
            z=dict(model=name,outcome=y,contrast=label,N=r['N'],persons=r['persons'],effective_N=r['effective_N'],psus=r['psus'],strata=r['strata'],df=r['design_df'],singleton_strata=r['singleton_strata'],iterations=r['iterations'],**contrast(r,y,ct))
            rows.append(z)
            if label=='ages18_34':print(name,y,f"{100*z['effect']:+.3f} pp [{100*z['lo95']:+.3f},{100*z['hi95']:+.3f}] N={r['N']}",flush=True)
    return rows

def resource_and_weight_checks(q,iterms,gross,net):
    obs=q[q.response==1].copy();b=obs[obs.source=='BHPS'].copy()
    btrip=b[b.previous_gap.between(6,18)&b.previous_save.notna()].copy()
    u=obs[obs.source=='UKHLS'].copy();utrip=u[u.previous_gap.between(6,18)&u.previous_save.notna()].copy()
    by=['save','next_save','next_minus_current'];uy=['previous_save','next_save','next_minus_previous']
    bn=b.dropna(subset=net);un=utrip.dropna(subset=net)
    configs=[
      ('BHPS_individual_direct_pairs',b,by,iterms,None,True,2),
      ('BHPS_gross_household',b,by,gross,None,True,2),
      ('BHPS_gross_on_net_sample',bn,by,gross,None,True,2),
      ('BHPS_net_household',bn,by,net,None,True,2),
      ('BHPS_gross_original_triplets',btrip,by,gross,None,True,2),
      ('UKHLS_gross_future',u,['next_save'],gross,None,True,2),
      ('UKHLS_net_future',u,['next_save'],net,None,True,2),
      ('UKHLS_gross_timing',utrip,uy,gross,None,True,2),
      ('UKHLS_net_timing',un,uy,net,None,True,2),
      ('pooled_gross_future',obs,['next_save'],gross,None,True,2),
      ('BHPS_gross_published_lw',b,by,gross,'next_published_pair_weight',True,2),
      ('BHPS_net_published_lw',bn,by,net,'next_published_pair_weight',True,2),
      ('BHPS_gross_unweighted_positive_lw',b[b.next_published_pair_weight.notna()],by,gross,None,True,2),
      ('BHPS_gross_constant_GB91_lw',b,by,gross,'next_indin91_lw',True,2),
      ('UKHLS_gross_published_lw',u,['next_save'],gross,'next_published_pair_weight',True,2),
      ('UKHLS_gross_timing_published_lw',utrip,uy,gross,'next_published_trip_weight',True,2),
      ('pooled_gross_published_lw',obs,['next_save'],gross,'next_published_pair_weight',True,2),
      # Descriptive alternatives make reliance on within-person projections
      # and short individual histories visible.
      ('BHPS_gross_without_person_FE',b,by,gross,None,False,2),
      ('BHPS_gross_minT8',b,by,gross,None,True,8),
    ]
    rows=[]
    for name,f,ys,terms,w,fe,mt in configs:
        rows+=collect(name,f,ys,terms,w,fe,mt)
        pd.DataFrame(rows).to_csv(OUT/'resource_weight_estimates.csv',index=False)
    audit=q.groupby(['source','wave']).agg(baseline=('pidp','size'),known_exit=('known_exit','sum'),observed=('response','sum'),net=('equiv_net','count'),gross=('equiv_gross','count'),base_weight=('baseline_weight','count'),published_lw=('next_published_pair_weight','count'))
    audit.to_csv(OUT/'analysis_coverage.csv')

def main():
    synthetic_check()
    q,short,iterms,gross,net=make_panel()
    q.to_pickle(HERE/'analysis_panel_LOCAL.pkl')
    (OUT/'control_sets.json').write_text(json.dumps(dict(short=short,individual=iterms,gross=gross,net=net),indent=2))
    resource_and_weight_checks(q,iterms,gross,net)

if __name__=='__main__':main()
