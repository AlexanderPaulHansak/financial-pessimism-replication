from pathlib import Path
import pypdfium2 as pdfium
from pypdf import PdfReader
from PIL import Image,ImageOps,ImageDraw

HERE=Path(__file__).resolve().parent
file=HERE.parent.parent/'outputs'/'Doom_Spending_Final_Assessment.pdf'
dest=HERE/'render';dest.mkdir(exist_ok=True)
reader=PdfReader(file)
pdf=pdfium.PdfDocument(file)
thumbs=[]
for i,page in enumerate(pdf):
    img=page.render(scale=1.5).to_pil().convert('RGB')
    img.save(dest/f'page_{i+1}.png')
    print('PAGE',i+1,'TEXT_CHARS',len(reader.pages[i].extract_text()),'END',reader.pages[i].extract_text()[-160:].replace('\n',' '))
    thumb=img.copy();thumb.thumbnail((440,623))
    cell=Image.new('RGB',(460,655),'#DDE4E7');cell.paste(thumb,((460-thumb.width)//2,8))
    ImageDraw.Draw(cell).text((12,635),f'Page {i+1}',fill='black')
    thumbs.append(cell)
sheet=Image.new('RGB',(460*4,655*((len(thumbs)+3)//4)),'white')
for i,img in enumerate(thumbs):sheet.paste(img,((i%4)*460,(i//4)*655))
sheet.save(dest/'contact_sheet.png')
print('PAGES',len(pdf))
