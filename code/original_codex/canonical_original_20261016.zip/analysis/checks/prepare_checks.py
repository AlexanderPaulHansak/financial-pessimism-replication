"""Add household resources, published weights and interview dispositions.

Respondent data stay in the local work directory. Only metadata are exported.
"""
from pathlib import Path
import re,zipfile,json
import pandas as pd
import numpy as np

HERE=Path(__file__).resolve().parent
ROOT=HERE.parent
RAW=Path(r'C:\Hansak\Data\UKDA-6614-tab\tab')
DICT=zipfile.ZipFile(RAW.parent/'mrdoc'/'ukda_data_dictionaries.zip')
RESULT=HERE/'results';RESULT.mkdir(exist_ok=True)
d=pd.read_pickle(ROOT/'pilot_augmented_LOCAL.pkl')
metadata=[];frames=[];dispositions=[]

def labels(source,prefix,kind,variables):
    name=f'{source.lower()}/{prefix}_{kind}_ukda_data_dictionary.rtf'
    if name not in DICT.namelist():return
    s=DICT.read(name).decode('cp1252',errors='replace')
    s=re.sub(r'\\[a-z]+-?\d* ?',' ',s).replace('{','').replace('}','')
    for v in variables:
        m=re.search(r'Variable =\s+'+re.escape(v)+r'\s',s)
        if m:
            end=s.find('Pos. =',m.end())
            text=' '.join(s[m.start():end if end>=0 else None].split())
            metadata.append(dict(source=source,prefix=prefix,kind=kind,variable=v,description=text))

for (source,wave,prefix),g in d.groupby(['source','wave','prefix'],sort=True):
    wave=int(wave)
    path=RAW/source.lower()/f'{prefix}_indresp.tab'
    cols=pd.read_csv(path,sep='\t',nrows=0).columns.tolist()
    individual={
        'marital_validated':next((prefix+'_'+v for v in ['mastat_dv','mastat'] if prefix+'_'+v in cols),''),
        'children_ind':prefix+'_nchild_dv',
        'sample_status':prefix+'_sampst',
    }
    weightcols=[c for c in cols if re.search(r'_indin(?:91|99|01|us|ub|ui|g2)_(?:lw|xw)$',c)]
    chosen={k:v for k,v in individual.items() if v in cols}
    z=pd.read_csv(path,sep='\t',usecols=['pidp']+list(chosen.values())+weightcols,low_memory=False)
    z=z.rename(columns={v:k for k,v in chosen.items()})
    for c in weightcols:z=z.rename(columns={c:c[len(prefix)+1:]})
    for k in individual:
        if k not in z:z[k]=np.nan
    z['source']=source;z['wave']=wave
    hhpath=RAW/source.lower()/f'{prefix}_hhresp.tab'
    hc=pd.read_csv(hhpath,sep='\t',nrows=0).columns.tolist()
    # The current release includes additional derived net variables in BHPS
    # hhresp, although the older harmonisation guide describes a separate file.
    hmap={
        'hh_gross':prefix+'_fihhmngrs_dv','hh_net_ukhls':prefix+'_fihhmnnet1_dv',
        'hh_net_bhps_weekly':prefix+'_hhneti',
        'hh_net_bhps_real_equiv':prefix+'_hhnetde2',
        'eq_bhps':prefix+'_eq_moecd','eq_ukhls':prefix+'_ieqmoecd_dv',
        'hh_size':prefix+'_hhsize','hh_kids':prefix+'_nkids_dv',
        'hh_couples':prefix+'_ncouple_dv','hh_employed':prefix+'_nemp_dv',
        'tenure':prefix+'_tenure_dv','rent_gross_monthly':prefix+'_rentgrs_dv',
        'mortgage_monthly':prefix+'_xpmg_dv','housing_cost_monthly':prefix+'_houscost1_dv',
        'housing_benefit_adjust':prefix+'_hbadjust_dv',
        'hh_gross_imputed':prefix+('_fihhmni' if source=='BHPS' else '_fihhmngrs_if'),
        'household_interview_status':prefix+'_ivfho',
    }
    available={k:v for k,v in hmap.items() if v in hc}
    h=pd.read_csv(hhpath,sep='\t',usecols=[prefix+'_hidp']+list(available.values()),low_memory=False)
    assert not h[prefix+'_hidp'].duplicated().any()
    h=h.rename(columns={prefix+'_hidp':'hidp',**{v:k for k,v in available.items()}})
    for k in hmap:
        if k not in h:h[k]=np.nan
    # Join each person's actual household in this survey wave.
    hid=g[['pidp','hidp']]
    z=z.merge(hid,on='pidp',validate='one_to_one').merge(h,on='hidp',how='left',validate='many_to_one')
    z=z.drop(columns='hidp')
    frames.append(z)
    labels(source,prefix,'hhresp',list(available.values()))
    labels(source,prefix,'indresp',list(chosen.values())+weightcols+[prefix+'_jbstat'])
    spath=RAW/source.lower()/f'{prefix}_indsamp.tab'
    if spath.exists():
        sc=pd.read_csv(spath,sep='\t',nrows=0).columns
        outcomes=[c for c in [prefix+'_ivfio',prefix+'_ivfho'] if c in sc]
        # Issue files can contain movers twice with different outcomes.
        # Use resolved one-person cross-wave records below, rather than choose
        # arbitrarily between contradictory issue records.
        if wave in [2,13]:labels(source,prefix,'indsamp',outcomes)
    print('RESOURCES',source,wave,'N',len(z),'NET',','.join(v for k,v in available.items() if 'net' in k),flush=True)

new=pd.concat(frames,ignore_index=True)
assert not new.duplicated(['pidp','source','wave']).any()
dd=d.merge(new,on=['pidp','source','wave'],validate='one_to_one')
x=pd.read_csv(RAW/'ukhls'/'xwavedat.tab',sep='\t',usecols=['pidp','psu','strata','hhorig','sex_dv'],low_memory=False)
assert not x.pidp.duplicated().any()
dd=dd.merge(x,on='pidp',how='left',validate='many_to_one')
for c in ['hh_gross','hh_net_ukhls','hh_net_bhps_weekly','hh_net_bhps_real_equiv']:
    # Negative income may be legitimate self-employment losses; main models
    # use within-wave ranks, retaining all numeric income except special codes.
    dd[c]=dd[c].where(~dd[c].isin([-1,-2,-7,-8,-9]))
dd['eq_factor']=dd.eq_bhps.where(dd.source=='BHPS',dd.eq_ukhls)
dd['eq_factor']=dd.eq_factor.where(dd.eq_factor>0)
dd['equiv_gross']=dd.hh_gross/dd.eq_factor
dd['equiv_net']=np.where(dd.source=='BHPS',dd.hh_net_bhps_weekly*52/12/dd.eq_factor,dd.hh_net_ukhls/dd.eq_factor)
# End-user UKHLS net1 is before council tax; BHPS net current concept differs.
# Source-specific ranks avoid comparing those levels as an identical concept.
for c in ['hh_size','hh_kids','hh_couples','hh_employed','tenure','marital_validated']:
    dd[c]=dd[c].where(dd[c]>=0)
dd['employment_complete']=dd.employment_raw.where(dd.employment_raw.isin(list(range(1,16))+[97]))
for c in ['psu','strata']:dd[c]=dd[c].where(dd[c]>0)
for source,folder,name in [('BHPS','bhps','xwaveid_bh.tab'),('UKHLS','ukhls','xwaveid.tab')]:
    path=RAW/folder/name
    cols=pd.read_csv(path,sep='\t',nrows=0).columns
    prefs=dd.loc[dd.source==source,['prefix','wave']].drop_duplicates()
    wanted=['pidp']+[p+'_'+suffix for p in prefs.prefix for suffix in ['ivfio','ivfho'] if p+'_'+suffix in cols]
    xx=pd.read_csv(path,sep='\t',usecols=wanted,low_memory=False)
    assert not xx.pidp.duplicated().any()
    for _,r in prefs.iterrows():
        prefix=r.prefix
        if prefix+'_ivfio' not in xx:continue
        zz=xx[['pidp',prefix+'_ivfio']].rename(columns={prefix+'_ivfio':'interview_disposition'})
        zz['hh_disposition']=xx[prefix+'_ivfho'] if prefix+'_ivfho' in xx else np.nan
        zz['source']=source;zz['wave']=int(r.wave);dispositions.append(zz)
ss=pd.concat(dispositions,ignore_index=True)
ss['wave']-=1
ss=ss.rename(columns={'interview_disposition':'next_disposition','hh_disposition':'next_hh_disposition'})
dd=dd.merge(ss,on=['pidp','source','wave'],how='left',validate='one_to_one')
dd.to_pickle(HERE/'household_augmented_LOCAL.pkl')
pd.DataFrame(metadata).to_csv(RESULT/'variable_definitions.csv',index=False)
audit=dd.groupby(['source','wave']).agg(N=('pidp','size'),gross=('equiv_gross','count'),net=('equiv_net','count'),net_bhps=('hh_net_bhps_weekly','count'),eq=('eq_factor','count'),composition=('hh_size','count'),marital=('marital_validated','count'),psu=('psu','count'))
audit.to_csv(RESULT/'resource_coverage.csv')
wc=[]
for (source,wave),g in dd.groupby(['source','wave']):
    for c in g.columns:
        if c.startswith('indin') and (c.endswith('_lw') or c.endswith('_xw')):
            if g[c].notna().any():wc.append(dict(source=source,wave=wave,variable=c,N_positive=int((g[c]>0).sum()),N_nonmissing=int(g[c].count())))
pd.DataFrame(wc).to_csv(RESULT/'published_weight_coverage.csv',index=False)
print('RESOURCE_AUDIT',audit.to_string(),flush=True)
print('DISPOSITIONS',dd.groupby('source').next_disposition.value_counts().to_string(),flush=True)
