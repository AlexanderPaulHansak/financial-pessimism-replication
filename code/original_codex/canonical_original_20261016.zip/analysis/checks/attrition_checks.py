"""Response weighting and explicitly assumption-dependent missing-outcome checks.

Response includes interview, saving-item response, and the 6--18-month window.
Weights target the observed, covariate-complete baseline, not original nonresponders.
"""
from pathlib import Path
import json
import numpy as np
import pandas as pd
from check_stats import logit_irls,fit,contrast
from run_remaining import collect

HERE=Path(__file__).resolve().parent
OUT=HERE/'results'

def predictors(g,terms):
    names=terms+['age_scaled','history_save','history_missing','history_pess','history_young']
    x=g[names].to_numpy(float)
    keep=np.ptp(x,axis=0)>1e-10
    return np.column_stack([np.ones(len(g)),x[:,keep]]),['intercept']+np.array(names)[keep].tolist()

def main():
    q=pd.read_pickle(HERE/'analysis_panel_LOCAL.pkl')
    terms=json.loads((OUT/'control_sets.json').read_text())['gross']
    # All these predictors are measured before the missing follow-up outcome.
    q['age_scaled']=(q.age-40)/10
    q['history_save']=q.save.where(q.source=='BHPS',q.previous_save.where(q.previous_gap>0))
    q['history_missing']=q.history_save.isna().astype(float)
    q['history_save']=q.history_save.fillna(0)
    q['history_pess']=q.history_save*q.pess
    q['history_young']=q.history_save*q.young
    base=q[(~q.known_exit)&q.baseline_weight.notna()].dropna(subset=terms+['psu','strata','date_month']).copy()
    rows=[];audits=[];bounds=[];patterns=[]
    base['propensity']=np.nan;base['predicted_save']=np.nan
    for (source,wave),g in base.groupby(['source','wave']):
        X,names=predictors(g,terms)
        w=g.baseline_weight.to_numpy();y=g.response.to_numpy()
        # Tiny ridge makes unobserved rare category combinations estimable.
        prob,b,it=logit_irls(X,y,w,ridge=1e-4,maxiter=100)
        prob_clip=np.clip(prob,.05,.995)
        base.loc[g.index,'propensity']=prob_clip
        ok=y==1
        # Linear probability imputation is only a sensitivity device.
        sw=np.sqrt(w[ok]);beta=np.linalg.lstsq(X[ok]*sw[:,None],g.loc[ok,'next_save'].to_numpy()*sw,rcond=None)[0]
        base.loc[g.index,'predicted_save']=np.clip(X@beta,0,1)
        audits.append(dict(source=source,wave=wave,N=len(g),observed=int(ok.sum()),response_unweighted=y.mean(),response_weighted=np.average(y,weights=w),predicted_response_weighted=np.average(prob,weights=w),p_min=prob.min(),p_01=np.quantile(prob,.01),p_median=np.median(prob),p_99=np.quantile(prob,.99),p_max=prob.max(),clipped_low=int((prob<.05).sum()),clipped_high=int((prob>.995).sum()),iterations=it,max_score=float(np.max(np.abs(X.T@(w/w.mean()*(y-prob))-1e-4*b)))))
        print('PROPENSITY',source,int(wave),len(g),f'response={np.average(y,weights=w):.3f}',f'pmin={prob.min():.3f}',flush=True)
    base['tailored_weight']=base.baseline_weight/base.propensity
    # Trim separately within forecast wave, preserving its relative scale.
    observed=base[base.response==1].copy()
    cap=observed.groupby(['source','wave']).tailored_weight.transform(lambda v:v.quantile(.99))
    observed['tailored_weight_cap99']=np.minimum(observed.tailored_weight,cap)
    for src,g in base.groupby('source'):
        young=g[g.young==1]
        for cat,h in young[young.fin_future_code.isin([2,3])].groupby('fin_future_code'):
            w=h.baseline_weight;ok=h.response==1
            lower=float((w[ok]*h.loc[ok,'next_save']).sum()/w.sum());miss=float(w[~ok].sum()/w.sum())
            bounds.append(dict(source=src,outlook='worse' if cat==2 else 'same',N=len(h),observed=int(ok.sum()),response_weighted=1-miss,observed_saving_rate=float(np.average(h.loc[ok,'next_save'],weights=w[ok])),lower=lower,upper=lower+miss))
        for youngflag,hh in g.groupby('young'):
            for cat,h in hh.groupby('fin_future_code'):
                patterns.append(dict(source=src,young=int(youngflag),outlook=int(cat),N=len(h),observed=int(h.response.sum()),response_weighted=np.average(h.response,weights=h.baseline_weight)))
    pd.DataFrame(audits).to_csv(OUT/'response_propensity_audit.csv',index=False)
    pd.DataFrame(bounds).to_csv(OUT/'attrition_worst_case_bounds.csv',index=False)
    pd.DataFrame(patterns).to_csv(OUT/'response_by_outlook.csv',index=False)
    for src in ['BHPS','UKHLS']:
        g=observed[observed.source==src].copy()
        ys=['save','next_save','next_minus_current'] if src=='BHPS' else ['next_save']
        for lab,weight in [('base_xw','baseline_weight'),('tailored_ipw','tailored_weight'),('tailored_ipw_cap99','tailored_weight_cap99')]:
            rows+=collect(src+'_'+lab,g,ys,terms,weight)
            pd.DataFrame(rows).to_csv(OUT/'attrition_weight_estimates.csv',index=False)
        if src=='UKHLS':
            h=g[g.previous_gap.between(6,18)&g.previous_save.notna()]
            rows+=collect('UKHLS_timing_tailored_ipw',h,['previous_save','next_save','next_minus_previous'],terms,'tailored_weight')
            pd.DataFrame(rows).to_csv(OUT/'attrition_weight_estimates.csv',index=False)
    tails=[]
    for (src,wv),g in observed.groupby(['source','wave']):
        w=g.tailored_weight.to_numpy()
        tails.append(dict(source=src,wave=wv,N=len(g),weight_median=np.median(w),weight_p99=np.quantile(w,.99),weight_max=w.max(),effective_N=w.sum()**2/(w@w)))
    pd.DataFrame(tails).to_csv(OUT/'tailored_weight_audit.csv',index=False)
    # MNAR pattern-mixture check: raise/lower the saving probability of ONLY
    # missing pessimistic follow-ups by delta relative to the MAR prediction.
    # These are completed-data point projections, never valid confidence CIs.
    sens=[]
    for src in ['BHPS','UKHLS']:
        g=base[base.source==src].copy();ys=[];scenarios=[]
        for i,delta in enumerate([-.2,-.1,0,.1,.2,.4,1.0]):
            name='completed_next_'+str(i)
            g[name]=g.next_save.where(g.response==1,(g.predicted_save+delta*g.pess).clip(0,1))
            ys.append(name);scenarios.append((delta,name,'completed_next'))
            if src=='BHPS':
                change='completed_change_'+str(i);g[change]=g[name]-g.save
                ys.append(change);scenarios.append((delta,change,'completed_change'))
        r=fit(g,ys,terms,weight='baseline_weight',design=True)
        for delta,name,label in scenarios:
            z=contrast(r,name,{'pess':1,'pess_young':1})
            sens.append(dict(source=src,delta_pessimistic_missing=delta,outcome=label,N=r['N'],persons=r['persons'],effect=z['effect']))
            print('MNAR',src,delta,label,round(z['effect']*100,3),flush=True)
        pd.DataFrame(sens).to_csv(OUT/'MNAR_point_sensitivity.csv',index=False)
    # Cross-wave-missingness of controls and zero baseline weights remain exclusions.
    q.groupby('source').agg(scheduled=('pidp','size'),known_exit=('known_exit','sum'),response=('response','sum')).join(base.groupby('source').agg(response_risk_set=('pidp','size'),risk_set_observed=('response','sum'))).to_csv(OUT/'attrition_risk_set.csv')
    base.to_pickle(HERE/'attrition_base_LOCAL.pkl')

if __name__=='__main__':main()
