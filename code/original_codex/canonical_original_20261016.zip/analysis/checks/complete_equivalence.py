from pathlib import Path
import pandas as pd
import numpy as np
HERE=Path(__file__).resolve().parent
RAW=Path(r'C:\Hansak\Data\UKDA-6614-tab\tab')
d=pd.read_pickle(HERE/'household_augmented_LOCAL.pkl')
frames=[];audit=[]
for prefix in d.loc[d.source=='BHPS','prefix'].unique():
    path=RAW/'bhps'/f'{prefix}_indall.tab'
    cols=pd.read_csv(path,sep='\t',nrows=0).columns
    age=next(c for c in [prefix+'_age_dv',prefix+'_age'] if c in cols)
    a=pd.read_csv(path,sep='\t',usecols=[prefix+'_hidp',age])
    a=a.rename(columns={prefix+'_hidp':'hidp',age:'age'})
    a['valid']=a.age.between(0,110)
    a['adult14']=(a.age>=14)&a.valid
    a['child13']=(a.age<14)&a.valid
    z=a.groupby('hidp').agg(roster_n=('age','size'),valid_n=('valid','sum'),adult14=('adult14','sum'),child13=('child13','sum')).reset_index()
    z['eq_roster']=(1+.5*(z.adult14-1)+.3*z.child13).where((z.adult14>=1)&(z.valid_n==z.roster_n))
    h=d[d.prefix==prefix][['hidp','hh_size','eq_bhps']].drop_duplicates('hidp')
    z=z.merge(h,on='hidp',how='left',validate='one_to_one')
    mismatch=z.hh_size.notna()&(z.roster_n!=z.hh_size)
    z.loc[mismatch,'eq_roster']=np.nan
    comparable=(z.eq_bhps>0)&z.eq_roster.notna()
    error=(z.loc[comparable,'eq_bhps']-z.loc[comparable,'eq_roster']).abs()
    audit.append(dict(prefix=prefix,households=len(z),size_conflicts=int(mismatch.sum()),N_equiv=int(z.eq_roster.count()),native_over_computed_median=float((z.eq_bhps/z.eq_roster).median()),native_comparisons=int(comparable.sum()),native_differences_tol1e6=int((error>1e-6).sum()),native_max_absolute_difference=float(error.max())))
    z['prefix']=prefix
    frames.append(z[['prefix','hidp','eq_roster']])
z=pd.concat(frames,ignore_index=True)
d=d.drop(columns=['eq_roster'],errors='ignore').merge(z,on=['prefix','hidp'],how='left',validate='many_to_one')
d['eq_check']=d.eq_roster.where(d.source=='BHPS',d.eq_ukhls)
d['eq_check']=d.eq_check.where(d.eq_check>0)
d['equiv_gross']=d.hh_gross/d.eq_check
d['equiv_net']=np.where(d.source=='BHPS',d.hh_net_bhps_weekly*52/12/d.eq_check,d.hh_net_ukhls/d.eq_check)
d.to_pickle(HERE/'household_augmented_LOCAL.pkl')
pd.DataFrame(audit).to_csv(HERE/'results'/'equivalence_audit.csv',index=False)
d.groupby(['source','wave']).agg(N=('pidp','size'),gross=('equiv_gross','count'),net=('equiv_net','count'),net_bhps=('hh_net_bhps_weekly','count'),eq=('eq_check','count'),composition=('hh_size','count'),marital=('marital_validated','count'),psu=('psu','count')).to_csv(HERE/'results'/'resource_coverage.csv')
print(pd.DataFrame(audit).to_string(index=False))
print(d.groupby('source')[['equiv_gross','equiv_net','hh_gross','eq_check']].count().to_string())
