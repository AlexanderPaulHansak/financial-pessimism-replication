"""Weighted fixed-effect projections and survey-clustered inference.

This module implements a conditional linear projection, not causal estimation.
"""
import numpy as np
import pandas as pd
import math

def absorb(a,groups,w,tol=1e-9,maxiter=3000):
    a=np.asarray(a,dtype=float).copy()
    codes=[pd.factorize(g)[0] for g in groups]
    denom=[np.bincount(ix,weights=w) for ix in codes]
    for i in range(maxiter):
        old=a.copy()
        for ix,den in zip(codes,denom):
            means=np.column_stack([np.bincount(ix,weights=w*a[:,j],minlength=len(den)) for j in range(a.shape[1])])/den[:,None]
            a-=means[ix]
        if np.max(np.abs(a-old))<tol:return a,i+1
    raise RuntimeError('Weighted fixed effects did not converge')

def _rank_fe(p,t):
    pc,ps=pd.factorize(p);tc,ts=pd.factorize(t)
    par=np.arange(len(ps)+len(ts))
    def root(x):
        while par[x]!=x:
            par[x]=par[par[x]];x=par[x]
        return x
    for a,b in zip(pc,tc):
        u,v=root(a),root(len(ps)+b)
        if u!=v:par[v]=u
    return len(ps)+len(ts)-len({root(i) for i in range(len(par))})

def fit(frame,outcomes,terms,weight=None,fe=True,design=True,minT=2):
    cols=list(dict.fromkeys(outcomes+terms+['pidp','timecell','pess','source','wave']+(['psu','strata'] if design else [])+([weight] if weight else [])))
    a=frame[cols].replace([np.inf,-np.inf],np.nan).dropna().copy()
    if weight:a=a[a[weight]>0].copy()
    if fe:
        while True:
            ok=(a.groupby('pidp').pidp.transform('size')>=minT)&(a.groupby('timecell').pidp.transform('size')>=2)
            if ok.all():break
            a=a[ok].copy()
    if len(a)==0:raise RuntimeError('Empty estimation sample')
    w=a[weight].to_numpy(float) if weight else np.ones(len(a))
    w=w/w.mean()
    groups=[a.pidp,a.timecell] if fe else [a.timecell]
    z,it=absorb(a[outcomes+terms].to_numpy(),groups,w)
    k0=len(outcomes)
    Y=z[:,:k0]*np.sqrt(w[:,None]);X=z[:,k0:]*np.sqrt(w[:,None])
    keep=np.max(np.abs(X),axis=0)>1e-8
    names=np.array(terms)[keep].tolist();X=X[:,keep]
    b,_,rank,_=np.linalg.lstsq(X,Y,rcond=None)
    if rank!=len(names):raise RuntimeError('Regressor rank deficiency')
    residual=Y-X@b
    bread=np.linalg.inv(X.T@X)
    arank=_rank_fe(a.pidp,a.timecell) if fe else a.timecell.nunique()
    n=len(a);npar=arank+rank
    covs=[];cluster_info={}
    for j in range(k0):
        score=X*residual[:,j,None]
        if design:
            pairs=a[['strata','psu']].drop_duplicates().reset_index(drop=True)
            key=pd.MultiIndex.from_frame(a[['strata','psu']])
            ix=pd.MultiIndex.from_frame(pairs).get_indexer(key)
            sums=np.zeros((len(pairs),rank));np.add.at(sums,ix,score)
            meat=np.zeros((rank,rank));singleton=0
            for _,gg in pairs.groupby('strata'):
                s=sums[gg.index];m=len(s)
                if m>1:
                    s=s-s.mean(axis=0);meat+=m/(m-1)*(s.T@s)
                else:
                    # Centered singleton treatment. Total regression score is
                    # zero, so grand centering is numerically zero here.
                    singleton+=1;meat+=s.T@s
            df=len(pairs)-pairs.strata.nunique()
            cv=bread@meat@bread*(n-1)/(n-npar)
            cluster_info=dict(psus=len(pairs),strata=pairs.strata.nunique(),design_df=df,singleton_strata=singleton)
        else:
            ix,unique=pd.factorize(a.pidp)
            sums=np.zeros((len(unique),rank));np.add.at(sums,ix,score)
            cv=bread@(sums.T@sums)@bread*len(unique)/(len(unique)-1)*(n-1)/(n-npar)
            cluster_info=dict(psus=0,strata=0,design_df=len(unique)-1,singleton_strata=0)
        covs.append(cv)
    # Cornish-Fisher t critical value is accurate at these large design df.
    df=max(2,cluster_info['design_df']);zcrit=1.959963984540054
    crit=zcrit+(zcrit**3+zcrit)/(4*df)+(5*zcrit**5+16*zcrit**3+3*zcrit)/(96*df**2)
    return dict(N=n,persons=a.pidp.nunique(),terms=names,beta=b,cov=covs,outcomes=outcomes,
        effective_N=float(w.sum()**2/(w@w)),iterations=it,crit=crit,
        age_young_N=int((a['pess']*0+frame.loc[a.index,'young']).sum()),
        **cluster_info)

def contrast(r,y,ct):
    j=r['outcomes'].index(y)
    w=np.array([ct.get(t,0) for t in r['terms']])
    beta=float(w@r['beta'][:,j]);se=math.sqrt(max(0,float(w@r['cov'][j]@w)))
    return dict(effect=beta,se=se,lo95=beta-r['crit']*se,hi95=beta+r['crit']*se)

def logit_irls(X,y,w,ridge=1e-7,maxiter=70):
    X=np.asarray(X,float);y=np.asarray(y,float);w=np.asarray(w,float);w=w/w.mean()
    b=np.zeros(X.shape[1]);pen=np.eye(X.shape[1])*ridge
    for i in range(maxiter):
        eta=np.clip(X@b,-25,25);p=1/(1+np.exp(-eta))
        grad=X.T@(w*(y-p))-pen@b
        H=X.T@((w*p*(1-p))[:,None]*X)+pen
        step=np.linalg.solve(H,grad)
        oldloss=np.sum(w*(np.logaddexp(0,eta)-y*eta))+.5*b@pen@b
        factor=1
        for _ in range(20):
            bb=b+factor*step;ee=X@bb
            loss=np.sum(w*(np.logaddexp(0,ee)-y*ee))+.5*bb@pen@bb
            if loss<=oldloss+1e-7:break
            factor*=.5
        b=bb
        if np.max(np.abs(factor*step))<1e-7:break
    p=1/(1+np.exp(-np.clip(X@b,-25,25)))
    if i==maxiter-1:raise RuntimeError('Logit not converged')
    return p,b,i+1

def synthetic_check():
    rng=np.random.default_rng(312)
    p=np.repeat(np.arange(80),5);t=np.tile(np.arange(5),80);ok=rng.random(len(p))>.15
    p=p[ok];t=t[ok];x=rng.normal(size=len(p));w=np.exp(rng.normal(size=len(p))*.3)
    y=.7*x+rng.normal(size=80)[p]+rng.normal(size=5)[t]+rng.normal(size=len(p))*.3
    frame=pd.DataFrame(dict(pidp=p,timecell=t,pess=(x>0).astype(float),young=(p<40).astype(float),source='S',wave=t,x=x,y=y,w=w,psu=p//4+1,strata=p//8+1))
    r=fit(frame,['y'],['x'],weight='w',design=False)
    D=np.column_stack([x,pd.get_dummies(p,dtype=float).to_numpy(),pd.get_dummies(t,dtype=float).to_numpy()[:,1:]])
    Dw=D*np.sqrt(w[:,None]);yw=y*np.sqrt(w)
    b=np.linalg.lstsq(Dw,yw,rcond=None)[0];ee=yw-Dw@b
    sc=np.zeros((80,D.shape[1]));np.add.at(sc,p,Dw*ee[:,None])
    inv=np.linalg.inv(Dw.T@Dw)
    cv=inv@(sc.T@sc)@inv*80/79*(len(p)-1)/(len(p)-np.linalg.matrix_rank(D))
    assert abs(r['beta'][0,0]-b[0])<1e-7
    assert abs(r['cov'][0][0,0]-cv[0,0])<1e-7
    # Survey-stratified cluster covariance against explicit full dummies.
    rr=fit(frame,['y'],['x'],weight='w',design=True)
    sc=np.zeros((20,D.shape[1]));np.add.at(sc,p//4,Dw*ee[:,None])
    meat=np.zeros((D.shape[1],D.shape[1]))
    for h in range(10):
        s=sc[2*h:2*h+2];s-=s.mean(axis=0);meat+=2*(s.T@s)
    cv=inv@meat@inv*(len(p)-1)/(len(p)-np.linalg.matrix_rank(D))
    assert abs(rr['cov'][0][0,0]-cv[0,0])<1e-7
    # Verify IRLS likelihood score and known constant-probability solution.
    yy=np.array([0,0,0,1,1],float);pp,bb,_=logit_irls(np.ones((5,1)),yy,np.ones(5),ridge=0)
    assert np.max(np.abs(pp-.4))<1e-7
    print('WEIGHTED_FE_AND_SURVEY_COVARIANCE_CHECK PASS',flush=True)
