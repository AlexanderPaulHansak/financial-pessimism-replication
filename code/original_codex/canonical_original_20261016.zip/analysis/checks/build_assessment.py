from pathlib import Path
from xml.sax.saxutils import escape
import json
import pandas as pd
from reportlab.platypus import SimpleDocTemplate,Paragraph,Spacer,Table,TableStyle,PageBreak
from reportlab.lib.styles import getSampleStyleSheet,ParagraphStyle
from reportlab.lib import colors
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.graphics.shapes import Drawing,Line,String,Circle

HERE=Path(__file__).resolve().parent
OUT=HERE.parent.parent/'outputs';OUT.mkdir(exist_ok=True)
R=HERE/'results'
e=pd.read_csv(R/'resource_weight_estimates.csv')
a=pd.read_csv(R/'attrition_weight_estimates.csv')
h=pd.read_csv(R/'history_estimates.csv')
t=pd.read_csv(R/'weighted_transition_estimates.csv')
m=pd.read_csv(R/'MNAR_point_sensitivity.csv')
b=pd.read_csv(R/'attrition_worst_case_bounds.csv')
r=pd.read_csv(R/'response_by_outlook.csv')
navy=colors.HexColor('#153349');teal=colors.HexColor('#0C777A');gray=colors.HexColor('#51616E');pale=colors.HexColor('#EEF5F5')
for name,file in [('Arial','arial.ttf'),('Arial-Bold','arialbd.ttf'),('Arial-Italic','ariali.ttf')]:
    pdfmetrics.registerFont(TTFont(name,str(Path('C:/Windows/Fonts')/file)))
pdfmetrics.registerFontFamily('Arial',normal='Arial',bold='Arial-Bold',italic='Arial-Italic',boldItalic='Arial-Bold')
styles=getSampleStyleSheet()
for name,size,leading,color,font in [('BodyA',10,14,navy,'Arial'),('SmallA',8.5,11.5,gray,'Arial'),('TitleA',25,29,navy,'Arial-Bold'),('HeadA',16,21,navy,'Arial-Bold'),('SubA',11,15,teal,'Arial-Bold'),('TableA',8.6,11.4,navy,'Arial'),('TagA',9,12,teal,'Arial-Bold')]:
    styles.add(ParagraphStyle(name=name,fontName=font,fontSize=size,leading=leading,textColor=color,spaceAfter=8))
story=[]
def p(s,sty='BodyA'):story.append(Paragraph(s,styles[sty]))
def sub(s):p(s,'SubA')
def page(s,tag):
    if story:story.append(PageBreak())
    p(tag.upper(),'TagA');p(s,'HeadA')
def tab(rows,widths):
    data=[[Paragraph(str(x),styles['TableA']) for x in row] for row in rows]
    z=Table(data,colWidths=widths,repeatRows=1,hAlign='LEFT')
    z.setStyle(TableStyle([('VALIGN',(0,0),(-1,-1),'TOP'),('BACKGROUND',(0,0),(-1,0),pale),('LINEBELOW',(0,0),(-1,0),.8,teal),('LINEBELOW',(0,1),(-1,-1),.25,colors.HexColor('#D7E1E5')),('TOPPADDING',(0,0),(-1,-1),6),('BOTTOMPADDING',(0,0),(-1,-1),6),('LEFTPADDING',(0,0),(-1,-1),6),('RIGHTPADDING',(0,0),(-1,-1),6)]))
    story.append(z);story.append(Spacer(1,9))
def row(df,model,outcome,ct='ages18_34'):return df[(df.model==model)&(df.outcome==outcome)&(df.contrast==ct)].iloc[0]
def eff(z,flip=False):
    v,lo,hi=z.effect,z.lo95,z.hi95
    if flip:v,lo,hi=-v,-hi,-lo
    return f'{100*v:+.2f}<br/>[{100*lo:+.2f}, {100*hi:+.2f}]'
def n(z):return f'{int(z.N):,}'
def inline(z):return f'{100*z.effect:+.2f} pp [{100*z.lo95:+.2f}, {100*z.hi95:+.2f}]'
def link(text,url):return f'<link href="{escape(url)}" color="#0C777A">{escape(text)}</link>'
def footer(c,doc):
    c.setStrokeColor(colors.HexColor('#CBD9DF'));c.line(49,43,546,43)
    c.setFont('Arial',8);c.setFillColor(gray)
    c.drawString(49,29,'Doom Spending project | Completed checks and assessment | 15 October 2026')
    c.drawRightString(546,29,str(doc.page))

page('Enough for a small paper?','01 / Decision')
p('<b>My judgment: yes for a modest, descriptive research note; no for the original doom-spending mechanism paper.</b> The historical BHPS timing result survives household-resource controls, published longitudinal weights and response adjustment. Its contribution is narrower than the original motivation and its publication prospects remain uncertain.')
p('<b>Recommended title:</b> <i>Financial Pessimism and the Timing of Saving: British Panel Evidence.</i> Make the annual BHPS comparison the main result, with UKHLS as a separate, less precise extension. Do not advertise the pooled coefficient as evidence of a new behaviour among today\'s young adults.')
sub('The result worth writing about')
tab([['Pessimistic versus unchanged outlook, ages 18-34','BHPS, pp [95% CI]'],
    ['Saving at the forecast interview',eff(row(e,'BHPS_gross_published_lw','save'))],
    ['Saving at the next interview, 6-18 months later',eff(row(e,'BHPS_gross_published_lw','next_save'))],
    ['Change: subsequent minus current saving',eff(row(e,'BHPS_gross_published_lw','next_minus_current'))]], [302,193])
p('These three estimates use <b>the same 104,848 observations from 12,644 people</b>, ages 18-59 at the forecast interview. They include person and survey-wave-by-interview-year fixed effects, individual and household controls, endpoint longitudinal weights, and standard errors allowing for survey strata and primary sampling units. Forecasts are from the BHPS period; saving outcomes extend to 2008. These are conditional associations, not effects of an exogenous change in beliefs.','SmallA')
sub('Why the verdict is qualified')
p('The timing reversal is stronger than a generic statement that pessimists save less. But anticipatory saving and consumption smoothing are established ideas. The gain is an explicit, matched-observation comparison of saving horizons and transitions, with a clear measurement warning. That is a plausible contribution for a short applied note, rather than a major theoretical advance.')
p('The weighted young-adult UKHLS forecast-to-saving estimate is <b>'+inline(row(e,'UKHLS_gross_published_lw','next_save'))+'</b>. Its before-versus-after timing contrast also includes zero. These estimates neither establish a recent youth-specific effect nor demonstrate that the historical pattern disappeared. The saving modules in this release end in 2023.')
p('<b>Recommendation:</b> write and circulate one compact note around the timing result. Keep the broader doom-spending story as motivation only. I would stop further structural calibration or mechanism hunting for this version of the project.')

page('Household resources do not remove the pattern','02 / Resource checks')
tab([['BHPS model, ages 18-34','Current S','Next S','Change','N'],
    *[[lab,eff(row(e,model,'save')),eff(row(e,model,'next_save')),eff(row(e,model,'next_minus_current')),n(row(e,model,'save'))] for lab,model in [
        ('Individual controls','BHPS_individual_direct_pairs'),('Add gross household resources','BHPS_gross_household'),('Gross resources, net-income sample','BHPS_gross_on_net_sample'),('Replace gross with net resources','BHPS_net_household'),('Net resources + published weights','BHPS_net_published_lw')]]], [155,85,85,85,85])
p('All entries are percentage points with 95% confidence intervals. Gross-versus-net comparisons on the same net-income sample are almost identical. Thus the result is not an obvious consequence of using personal gross income alone or of dropping households with missing net income. The richer controls are also used in the weighting and attrition checks below.','SmallA')
sub('What was added and checked')
p('Household income is equivalized with the modified OECD scale and ranked within each source and survey wave. Models add household size, children, employed household members, marital status and housing tenure, while retaining current financial-management category and personal gross-income rank. All valid employment categories, including codes 12-15 and 97, are retained; cohabitation code 10 is retained in the marital controls.')
p('The BHPS household file contains <b>hhneti</b>, a weekly net-income measure. The older extraction had missed it. I converted its periodicity and computed the equivalence scale from the complete household roster, so missing published equivalence values do not unnecessarily discard otherwise usable gross-income records. Roster counts match reported household size in every wave; two household age rosters are incomplete. Native and reconstructed factors agree within 0.000001 for 99.85% of 109,688 comparable households; 165 differ by up to 0.2. Both gross and net models use the consistent roster factor.')
coverage=pd.read_csv(R/'resource_coverage.csv').groupby('source')[['gross','net']].sum()
p('After cleaning special missing codes and requiring positive equivalence factors, the augmented extract has usable equivalized gross/net resources for <b>'+f'{int(coverage.loc["BHPS","gross"]):,} / {int(coverage.loc["BHPS","net"]):,}'+' BHPS person-wave records</b> and <b>'+f'{int(coverage.loc["UKHLS","gross"]):,} / {int(coverage.loc["UKHLS","net"]):,}'+' UKHLS records</b>. Estimation imposes further age, timing, covariate, weight and panel-history requirements.')
sub('The remaining measurement boundary')
p('BHPS net income and UKHLS <b>fihhmnnet1_dv</b> are not perfectly identical concepts: the latter is before council tax, and the BHPS net-income file uses a more restrictive household-response rule [8,9]. I therefore use source-specific ranks, show source-specific estimates and avoid interpreting pooled nominal income levels as harmonized disposable resources.')
p('These checks measure income and household circumstances. They do not provide a complete annual measure of liquid wealth, debt service or disposable resources after housing costs. They cannot establish that people built a buffer and then depleted it. That mechanism must remain an interpretation, not a finding.')

page('Weighting and observed attrition are not driving BHPS','03 / Selection checks')
tab([['BHPS specification, ages 18-34','Next saving, pp [95% CI]','Timing change, pp [95% CI]','N'],
    *[[lab,eff(row(df,model,'next_save')),eff(row(df,model,'next_minus_current')),n(row(df,model,'next_save'))] for lab,df,model in [
      ('Unweighted, household controls',e,'BHPS_gross_household'),('Published longitudinal weights',e,'BHPS_gross_published_lw'),('Unweighted, positive-LW sample',e,'BHPS_gross_unweighted_positive_lw'),('GB 1991 sample, published LW',e,'BHPS_gross_constant_GB91_lw'),('Baseline cross-sectional weights',a,'BHPS_base_xw'),('Tailored response weights',a,'BHPS_tailored_ipw'),('Tailored weights, cap at 99th percentile',a,'BHPS_tailored_ipw_cap99')]]], [187,112,112,84])
p('The base-XW and tailored-IPW rows share a baseline-weight-positive, covariate-complete response risk set. They do not use the endpoint-LW sample. CIs for tailored weights are conditional on estimated response probabilities and do not incorporate first-stage estimation uncertainty. The published-weight result provides the main inference; IPW is an additional selection check.','SmallA')
sub('How the weights were chosen')
p('I used the follow-up wave\'s individual-interview longitudinal weight whose base sample predates the earliest required observation. BHPS weights expand from the 1991 to 1999 and 2001 samples when the pair permits it; strict prior/forecast/future transitions use the older base when required. UKHLS uses US at endpoint Wave 2, UB at Waves 4/6, and UI at Waves 8/10/13. A fixed GB-1991 sensitivity avoids changing BHPS sample bases.')
p('Released longitudinal weights require continuous response from their base and therefore exclude some intermittent respondents. The tailored check starts from positive baseline cross-sectional weights and divides by the estimated probability of obtaining a usable saving follow-up 6-18 months later. Separate source-wave weighted logits use baseline outlook, age, household controls and observed saving history. Known deaths and out-of-scope/institutional exits are removed from the response risk set [8].')
p('Positive weights are normalized within source and forecast wave before pooling. This defines a pooled descriptive regression, not a national population saving rate. Inference aggregates person-wave scores within the stable PSU and stratification identifiers; sparse singleton strata use a centred-score treatment. The weighted estimator and covariance calculations pass an explicit full-dummy synthetic-data comparison.')

page('Missing outcomes still require assumptions','04 / Attrition sensitivity')
tab([['Young-adult baseline outlook','BHPS usable follow-up','UKHLS usable follow-up'],
    *[[lab,*[f"{100*r[(r.source==src)&(r.young==1)&(r.outlook==code)].iloc[0].response_weighted:.1f}%" for src in ['BHPS','UKHLS']]] for code,lab in [(2,'Expect worse finances'),(3,'Expect unchanged finances'),(1,'Expect better finances')]]], [225,135,135])
p('These are weighted follow-up rates in the eligible baseline risk set, before fixed-effect singleton removal. Follow-up includes interview response, answering the saving question and satisfying the date window. Baseline nonresponse, missing controls and zero baseline weights are not recovered by this adjustment.','SmallA')
sub('A transparent assumption-dependent stress test')
p('For missing follow-ups, I first predict saving from observed baseline characteristics within each forecast wave. I then increase only missing pessimists\' saving probability by the stated amount, clipping it to [0,1], while other missing outcomes retain their baseline-model prediction. The entries below are completed-data <b>point sensitivities, not estimates with valid confidence intervals</b>.')
def mr(src,delta):return m[(m.source==src)&(m.delta_pessimistic_missing==delta)&(m.outcome=='completed_next')].iloc[0]
tab([['Extra saving probability for missing pessimists','BHPS next-S contrast','UKHLS next-S contrast'],
    *[[lab,f'{100*mr("BHPS",delta).effect:+.2f} pp',f'{100*mr("UKHLS",delta).effect:+.2f} pp'] for delta,lab in [(0,'Baseline prediction (MAR-style)'),(.1,'+10 percentage points'),(.2,'+20 percentage points'),(.4,'+40 percentage points'),(1.0,'All missing pessimists save')]]], [225,135,135])
p('BHPS remains negative under this one-sided stress test. UKHLS is much more sensitive. This is not a proof against all nonrandom attrition: simultaneous adverse changes for missing respondents in the unchanged-outlook comparison group could produce a different result.')
sub('What assumption-free bounds say')
br=[]
for src in ['BHPS','UKHLS']:
    pp=b[(b.source==src)&(b.outlook=='worse')].iloc[0];ss=b[(b.source==src)&(b.outlook=='same')].iloc[0]
    br.append([src,f'[{100*(pp.lower-ss.upper):+.2f}, {100*(pp.upper-ss.lower):+.2f}] pp'])
tab([['Unadjusted young-adult P-minus-same contrast','Worst-case range'],*br],[302,193])
p('These bounds let every missing binary outcome equal 0 or 1 independently. They are bounds on weighted, unadjusted group saving rates in the baseline risk set, <b>not bounds or confidence intervals for the fixed-effect coefficient</b>. Both include zero. The honest conclusion is robustness to observed selection and specified stress tests, with residual uncertainty about unrestricted missing outcomes.')

page('Timing is the main result; age and period are secondary','05 / Robustness and transitions')
tab([['BHPS household-control comparison, ages 18-34','Current S','Next S','Change'],
    *[[lab,eff(row(df,model,'save')),eff(row(df,model,'next_save')),eff(row(df,model,'next_minus_current'))] for lab,df,model in [
        ('At least eight usable pairs',e,'BHPS_gross_minT8'),('Balanced Waves 4-14: 2,147 people',h,'BHPS_balanced_waves4_14'),('Time effects, without person effects',e,'BHPS_gross_without_person_FE')]]],[204,97,97,97])
p('The pattern survives long histories, a fixed 11-wave window and the model without person fixed effects. The timing contrast equals the future coefficient minus the current coefficient on identical observations. This identity is checked numerically in the verification script. Neither person effects nor differencing supply an exogenous belief shock.','SmallA')
sub('Transitions using saving measured strictly before the forecast')
tab([['Pessimism contrast, ages 18-34','BHPS, pp [95% CI]','UKHLS, pp [95% CI]'],
    ['Entry among previous non-savers',eff(row(t,'BHPS_prior_nonsavers','next_save')),eff(row(t,'UKHLS_prior_nonsavers','next_save'))],
    ['Exit among previous savers',eff(row(t,'BHPS_prior_savers','next_save'),True),eff(row(t,'UKHLS_prior_savers','next_save'),True)]],[225,135,135])
p('Both saving observations lie 6-18 months from the forecast, one before and one after, so these are transitions across roughly two years, not dated annual exit hazards. Published longitudinal weights cover all three required waves. Entry/exit regressions use different risk sets and drop people with insufficient observations in that state. BHPS supports both lower entry and higher exit; recent young-adult estimates are imprecise.','SmallA')
sub('What the age comparison can support')
p('In the weighted BHPS model, the timing contrast is <b>-9.35 pp for ages 18-34</b> and <b>-3.46 pp for ages 35-59</b>; their difference is <b>-5.89 pp [-9.22, -2.56]</b>. That is a historical age difference in this specification. The difference in the next-saving coefficient alone is <b>-2.09 pp [-4.64, +0.47]</b>, and UKHLS does not establish a comparable youth-specific contrast. Treat age heterogeneity as exploratory.')
p('The UKHLS weighted strict-timing comparison is <b>'+f'{100*row(e,"UKHLS_gross_timing_published_lw","previous_save").effect:+.2f}'+' pp before</b> and <b>'+f'{100*row(e,"UKHLS_gross_timing_published_lw","next_save").effect:+.2f}'+' pp after</b> the forecast, with a difference of <b>'+inline(row(e,'UKHLS_gross_timing_published_lw','next_minus_previous'))+'</b>. Saving is not asked annually in UKHLS; the prior observation is not contemporaneous saving. Keep the two surveys separate and avoid calling a significant historical estimate and an insignificant recent one a statistically established break.')

page('The closest economic papers leave limited room','06 / Literature comparison')
sub('Brown and Taylor (2006), Fiscal Studies [1]')
p('The published paper already connects the same year-ahead BHPS outlook to saving and future consumption; its abstract reports lower saving with optimism. The accessible May 2006 author version uses 1991-2001, a balanced panel of 4,249 people, current savings/income ratios and random-effects Tobit models (Section III; Table 5). Its optimism coefficient is negative; the pessimism dummy versus unchanged is not significant. Our binary saving participation and same-sample current/next reversal are different estimands. <b>Access limit:</b> I read the author version and published abstract, not the complete 1991-2003 journal article. Do not infer every final table from the older draft, or make an unqualified priority claim.')
sub('Guariglia (2001), Journal of Population Economics [2]')
p('This is a direct predecessor on BHPS saving and earnings uncertainty. Its publisher-hosted abstract, also reproduced with the reprinted chapter, explicitly reports more saving when households expect deterioration. Hence contemporaneous pessimism and precautionary saving are not new. Full article methods and tables were not accessible in this session; the comparison is limited to that established overlap. Our possible addition is subsequent saving participation and the paired timing contrast, not discovering precautionary behaviour.')
sub('Brown, Harris, Spencer and Taylor (2024), JMCB [3]')
p('I read the full journal article. It uses the same financial-outlook item in BHPS 1991-2008 (24,089 observations; 1,417 people) and studies durable expenditure and purchase participation. Its main contribution models excess unchanged responses with a generalized middle-inflated ordered probit; consumption models use generated expectation indices, correlated random effects and dynamic initial-condition controls (Sections 1-2; Tables 1,3,4). This is a different outcome and modelling contribution. It also shows why the unchanged category is not a pure control group and expectations may be endogenous. Our categorical contrasts do not solve either problem. The opportunity is a transparent saving-horizon comparison, not a superior causal design.')
sub('The conceptual mechanism is older still [4]')
p('Campbell\'s permanent-income analysis predicts saving in anticipation of declining labour income and tests it with US aggregate data. It already supplies the economic intuition for saving before a setback. A small note can document an informative microdata pattern around stated forecasts; it cannot claim anticipatory saving or consumption smoothing as a new theory.')
p('<b>Implication for novelty:</b> replacing optimism with pessimism, adding household controls, using fixed effects, or expanding the BHPS sample would not by itself be enough. The paper must foreground the jointly estimated horizon contrast and the difference between the survey measure and claims about resignation.')

page('The psychology and recent-expectations papers matter too','07 / Positioning the note')
sub('Gladstone and Pomerance (2025), JPSP [5]')
p('I read the main paper and online supplement. Study 7 uses UKHLS, general optimism over the previous two weeks, multiple saving measures and person fixed effects (pp. 173-183; Tables 23,26,28). The measure differs from a forecast of personal finances one year ahead; fixed effects and UKHLS savings are already covered. The supplement\'s financial-optimism check uses the cross-sectional BBC Big Money Test, rather than the annual BHPS/UKHLS forecast. Other studies and supplementary models examine lagged savings, so lagging an outcome is not novel. Table 28 also qualifies the income interaction. Their income description and SOM G variable listing differ; I do not treat their exact resource controls as established from the prose alone. Our defensible distinction is the forecast horizon and same-sample reversal, without claiming to overturn dispositional-optimism results.')
sub('Chapleau, Cooper and Hagler (2026), Boston Fed [6]')
p('I read the brief and regression appendix. US workers worried about AI-related job loss more often expect to save a lower income share next year. The linear-probability model controls for demographics, income, year and reported saving decline this year; the authors discuss both precautionary motives and limited resources. Thus worry and lower expected saving are already a current research topic. Our outcome is subsequently reported saving, rather than another intention, and our historical paired timing result is different. This paper does not identify the UK mechanism or make our historical sample contemporary.')
sub('Clark, D\'Ambrosio and Lepinteur (2023 accessible draft) [7]')
p('The Italian Fornero-reform study uses a firm-size difference-in-differences design and household saving/consumption outcomes. It reports precautionary responses that depend on resources and family structure. This is a stronger identification benchmark for a behavioural mechanism. Our forecasts have no comparable exogenous variation. The draft comparison supports a descriptive framing; it does not supply causal identification to our regressions.')
sub('The claim I would put in a paper')
p('<i>In historical British panel data, year-ahead financial pessimism is associated with greater reported saving at the forecast interview but lower saving at the following interview. The sign depends on when saving is measured. The reversal persists across resource and selection checks, while recent young-adult estimates are less precise.</i>')
p('That claim is empirically supported here. A claim that pessimism causes discretionary spending, reflects loss of agency, or marks a new generation\'s abandonment of long-term goals is not. Income controls do not eliminate anticipated future shocks or other time-varying confounding; repeated reports can also contain shared measurement error.')

page('A bounded paper, with reproducible evidence','08 / Writing decision and sources')
p('<b>Proceed with a short note of roughly 4,000-5,000 words.</b> Organize it around the measurement question, one BHPS timing table, the strict prior-saving entry/exit table, and the UKHLS extension. Put the resource, weighting, long-history and attrition checks in a compact appendix. A simple consumption-smoothing example is sufficient; the OLG model is unnecessary for this claim.')
p('The main publication risk is <b>incremental novelty</b>, not failure of the historical coefficient. The complete published Brown-Taylor article still needs a final priority check before submission; I have not claimed that access limitation is resolved. Even if the exact matched-horizon table is absent there, a referee may judge the result a useful replication rather than a standalone advance. I would write and circulate the note, but I would not promise acceptance or invest in a larger paper on this evidence.')
p('The accompanying ZIP contains the scripts, aggregate tables, variable metadata and verification results. No respondent records or downloaded copyrighted papers are packaged. The original project and source data were not changed. Earlier exploratory results are superseded by these resource-controlled, design-aware checks where the specifications overlap.','SmallA')
sub('Sources and access record')
refs=[
('1','Brown & Taylor (2006), Fiscal Studies 27(3), 313-338. Published abstract; author draft Section III/Table 5 read.', 'https://onlinelibrary.wiley.com/doi/abs/10.1111/j.1467-8578.2006.00037.x'),
('1a','Accessible May 2006 author version (1991-2001), distinct from the final journal sample.','https://eprints.whiterose.ac.uk/id/eprint/9944/1/SERP2006006.pdf'),
('2','Guariglia (2001), Journal of Population Economics 14(4), 619-634. Publisher abstract in reprinted chapter; full methods unavailable.','https://link.springer.com/chapter/10.1007/978-3-642-55573-2_8'),
('3','Brown et al. (2024), JMCB 56(4), 741-768. Full journal article read.','https://onlinelibrary.wiley.com/doi/10.1111/jmcb.13063'),
('4','Campbell (1987), Econometrica 55(6), 1249-1273. NBER working-paper abstract and publication record.','https://www.nber.org/papers/w1805'),
('5','Gladstone & Pomerance (2025), JPSP 128(1), 147-195. Main paper read.','https://www.apa.org/pubs/journals/releases/psp-psp1281147.pdf'),
('5a','Online supplement, especially SOM F (BBC financial optimism) and SOM G (variable measures), read.','https://supp.apa.org/psycarticles/supplemental/pspp0000530/pspp0000530_supp.html'),
('6','Chapleau et al. (2026), Current Policy Perspectives 26-9. Full brief and appendix read.','https://www.bostonfed.org/publications/current-policy-perspectives/2026/how-concerns-about-ai-and-affordability-affect-saving-expectations.aspx'),
('7','Clark et al. (2023 accessible conference draft), Job insecurity, savings and consumption: an Italian experiment.','https://www.ecineq.org/wp-content/uploads/2023/06/EcineqAMSE-42.pdf'),
('8','Understanding Society Main Survey User Guide, local release: weights/analysis guidance and net-income concepts.','https://doc.ukdataservice.ac.uk/doc/6614/mrdoc/pdf/6614_main_survey_user_guide.pdf'),
('9','BHPS derived net current household income guide, SN3909; introduction and income/equivalence definitions.','https://sp.ukdataservice.ac.uk/doc/3909/mrdoc/pdf/3909userguide.pdf')]
for num,desc,url in refs:p(f'[{num}] '+escape(desc)+' '+link('Open source',url),'SmallA')
(R/'literature_access_record.json').write_text(json.dumps([dict(id=x,title=y,url=z) for x,y,z in refs],indent=2),encoding='utf-8')
file=OUT/'Doom_Spending_Final_Assessment.pdf'
doc=SimpleDocTemplate(str(file),pagesize=(595.28,841.89),rightMargin=49,leftMargin=49,topMargin=45,bottomMargin=58,title='Financial Pessimism and Saving: Completed Checks and Assessment',author='Research assessment')
doc.build(story,onFirstPage=footer,onLaterPages=footer)
print(file)
