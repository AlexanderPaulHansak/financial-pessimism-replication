from pathlib import Path
import pandas as pd
import numpy as np

RAW=Path(r'C:\Hansak\Data\UKDA-6614-tab\tab')
LONG=Path(r'C:\Hansak\Data\UKHLS_derived\bhps_ukhls_cohort_long_raw.csv')
WORK=Path(__file__).resolve().parent
d=pd.read_csv(LONG)
assert not d.duplicated(['pidp','source','wave']).any()
frames=[]; audit=[]
for (src,wave,prefix),g in d.groupby(['source','wave','prefix'],sort=True):
    file=RAW/src.lower()/f'{prefix}_indresp.tab'
    cols=pd.read_csv(file,sep='\t',nrows=0).columns.tolist()
    mapping={
        'month':f'{prefix}_istrtdatm', 'day':f'{prefix}_istrtdatd',
        'finnow':f'{prefix}_finnow', 'gross_income':f'{prefix}_fimngrs_dv',
        'marital':f'{prefix}_mlstat', 'hidp':f'{prefix}_hidp',
        'savereg':f'{prefix}_savreg', 'saveterm':f'{prefix}_savey',
        'employment_raw':f'{prefix}_jbstat',
    }
    available={k:v for k,v in mapping.items() if v in cols}
    z=pd.read_csv(file,sep='\t',usecols=['pidp']+list(available.values()),low_memory=False)
    assert not z.pidp.duplicated().any()
    z=z.rename(columns={v:k for k,v in available.items()})
    z['source']=src;z['wave']=wave
    for k in mapping:
        if k not in z:z[k]=np.nan
    frames.append(z)
    audit.append(dict(source=src,wave=int(wave),N=len(z),**{k:available.get(k,'') for k in mapping}))
    print(src,int(wave),'read',len(z),flush=True)
a=pd.concat(frames,ignore_index=True)
d=d.merge(a,on=['pidp','source','wave'],validate='one_to_one')
d['finnow']=d.finnow.where(d.finnow.between(1,5))
d['gross_income']=d.gross_income.where(d.gross_income>=0)
d['employment_status']=d.employment_status.where(d.employment_status.between(1,11))
d['marital']=d.marital.where(d.marital.between(1,6))
d['month']=d.month.where(d.month.between(1,12))
d['date_month']=12*d.interview_year+d.month
d.to_pickle(WORK/'pilot_augmented_LOCAL.pkl')
pd.DataFrame(audit).to_csv(WORK/'raw_variables_audit.csv',index=False)
print('AUGMENTED',d.groupby('source')[['finnow','gross_income','month','marital']].count().to_string())
print('GROSS_INCOME_QUANTILES',d.groupby('source').gross_income.quantile([0,.5,.99,.999]).to_string())
